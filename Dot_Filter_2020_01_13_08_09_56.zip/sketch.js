var capture;

function setup() {
  createCanvas(640, 480);
  capture=createCapture(VIDEO);
  capture.size(width,height);
capture.hide();
 // background(0)
}

function draw() {
for(var count=0;count<500;count++)
{var x=random(width)
var y=random(height)
var couleur=capture.get(x,y)
fill (couleur)
 noStroke()
 ellipse(x,y,random(2,15))}
       
}
